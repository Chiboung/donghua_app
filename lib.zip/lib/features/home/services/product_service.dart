import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/product.dart';

/// Reads and writes catalog entries in the `products` Firestore
/// collection. [CloudinaryService] handles the cover photo itself —
/// this class only ever deals with the URL Cloudinary returns.
///
/// Visibility rule: an entry uploaded by an **admin** is public and
/// shows up for everyone; an entry uploaded by a plain **user** is
/// private and only that uploader ever sees it. This is enforced here
/// on the client by only ever *querying* for what a given viewer is
/// allowed to see — but that's not real security by itself. Firestore
/// security rules must mirror the same check server-side (see the
/// rules snippet in ProductService's doc comment below), otherwise a
/// modified client could simply query for everything.
///
/// Suggested rule for the `products` collection:
/// ```
/// allow read: if resource.data.uploaderRole == 'admin'
///   || (request.auth != null && resource.data.uploaderId == request.auth.uid);
/// allow create: if request.auth != null
///   && request.resource.data.uploaderId == request.auth.uid;
/// ```
class ProductService {
  ProductService._();
  static final ProductService instance = ProductService._();

  final CollectionReference<Map<String, dynamic>> _products =
      FirebaseFirestore.instance.collection('products');

  /// Live-updating list of entries a given viewer is allowed to see:
  /// every public (admin-uploaded) entry, plus [viewerUid]'s own
  /// entries if they have any private ones. Newest first.
  ///
  /// Pass `null` for [viewerUid] (signed-out) to see only public
  /// entries.
  ///
  /// Firestore can't express an OR across two different fields in one
  /// query, so this runs the "public" and "mine" queries separately
  /// and merges them client-side, de-duplicating by document id (an
  /// admin's own entries would otherwise satisfy both queries at once
  /// and show up twice).
  Stream<List<Product>> watchVisibleProducts(String? viewerUid) {
    final publicQuery = _products
        .where('uploaderRole', isEqualTo: 'admin')
        .orderBy('createdAt', descending: true);

    if (viewerUid == null) {
      return publicQuery.snapshots().map(
            (snapshot) => snapshot.docs.map(Product.fromFirestore).toList(),
          );
    }

    final ownQuery = _products
        .where('uploaderId', isEqualTo: viewerUid)
        .orderBy('createdAt', descending: true);

    return _mergeById(
      publicQuery.snapshots().map((s) => s.docs.map(Product.fromFirestore)),
      ownQuery.snapshots().map((s) => s.docs.map(Product.fromFirestore)),
    );
  }

  /// Combines two live product streams into one, keyed by document id
  /// (an id present in both — an admin's own upload — resolves to
  /// either copy since they're identical), re-sorted newest first, and
  /// re-emitted every time *either* source updates.
  ///
  /// Each source's *full* current result set is tracked separately
  /// (Firestore's `.snapshots()` always emits the complete matching
  /// set, not a delta) and the merge is recomputed from scratch each
  /// time — so a doc that stops matching a query (e.g. it's deleted)
  /// correctly disappears instead of lingering from a stale merge.
  Stream<List<Product>> _mergeById(
    Stream<Iterable<Product>> a,
    Stream<Iterable<Product>> b,
  ) {
    final controller = StreamController<List<Product>>.broadcast();
    List<Product>? latestA;
    List<Product>? latestB;
    StreamSubscription? subA, subB;

    void emit() {
      if (latestA == null || latestB == null) return; // wait for both sources
      final merged = <String, Product>{
        for (final p in latestA!) p.id: p,
        for (final p in latestB!) p.id: p,
      }.values.toList()
        ..sort((x, y) {
          final ax = x.createdAt;
          final ay = y.createdAt;
          if (ax == null || ay == null) return 0;
          return ay.compareTo(ax);
        });
      controller.add(merged);
    }

    controller.onListen = () {
      subA = a.listen(
        (products) {
          latestA = products.toList();
          emit();
        },
        onError: controller.addError,
      );
      subB = b.listen(
        (products) {
          latestB = products.toList();
          emit();
        },
        onError: controller.addError,
      );
    };
    controller.onCancel = () async {
      await subA?.cancel();
      await subB?.cancel();
    };

    return controller.stream;
  }

  /// Creates a new entry document and returns its generated id.
  Future<String> addProduct(Product product) async {
    final doc = await _products.add(product.toFirestore());
    return doc.id;
  }

  /// Saves edits to an existing entry. Only the fields in
  /// [Product.toUpdateFirestore] are touched — `createdAt`,
  /// `uploaderId`, and `uploaderRole` are left as they were, and
  /// `updatedAt` is stamped with the server clock.
  ///
  /// Callers are expected to have already checked that the current
  /// user owns [product] (see [ProductDetailScreen]'s `_isOwner`) —
  /// this only guards it server-side if mirrored into Firestore rules,
  /// e.g.:
  /// ```
  /// allow update: if request.auth != null
  ///   && resource.data.uploaderId == request.auth.uid;
  /// ```
  Future<void> updateProduct(Product product) async {
    await _products.doc(product.id).update(product.toUpdateFirestore());
  }
}
